"""Utility functions for shimmy."""
